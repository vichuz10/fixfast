from django.apps import AppConfig


class MechanicsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mechanics_app'
