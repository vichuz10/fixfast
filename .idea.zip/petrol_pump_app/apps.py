from django.apps import AppConfig


class PetrolPumpAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'petrol_pump_app'
